#ifndef FTOA_HEADER
#define FTOA_HEADER

void reverse(char *str, int len);
int itostr(int x, char *str, int d);
void ftoa(float n, char *str, int decPoints);

#endif