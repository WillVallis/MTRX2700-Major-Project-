#ifndef SOUND_HEADER
#define SOUND_HEADER
void caution_beep(int threshold, int distance, int *wait);
void success_beep();

#endif