#ifndef TIMER_HEADER
#define TIMER_HEADER

void initTimer();

void enableOutputCompare(int channel);

#endif